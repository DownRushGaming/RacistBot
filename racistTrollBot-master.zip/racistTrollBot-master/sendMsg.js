(function(recipient, message) {
   var recipientName = recipient,
       messageText = message.toString();


})();
