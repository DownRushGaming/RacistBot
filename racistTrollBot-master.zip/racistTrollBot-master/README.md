# racistTrollBot
a racist troll bot for discord servers, he is full of hate, and for some reason people like him

<h6>there are a lot of people fighting these days</h6>
which i personally feel is a good thing. i mean back in the day, if two people dissagreed, they would have a shootout, or duel. and before that, whoever had more power 
would just execute the other party.

for some reason, maybe because of frued's theory or some other psycobable, people like to fight with things

so i made a discord bot that will make rude and nasty comments and troll you so you can have something to hate

i don't know why, but it makes people happy?!?

if you want to add dialogue to this bot, feel free to make `JSON` files with stuff, i only ask that you try to make the replies: short, whitty (or dumb) and at least slightly offensive to someone
preferrably liberals or conservatives.

thank you.
